####################
# PwshRuntimeLayer #
####################
../../powershell-runtime/build-PwshRuntimeLayer.ps1
#################
# AWSToolsLayer #
#################
../../powershell-modules/AWSToolsforPowerShell/AWS.Tools.S3EventBridge/build-AWSToolsLayer.ps1