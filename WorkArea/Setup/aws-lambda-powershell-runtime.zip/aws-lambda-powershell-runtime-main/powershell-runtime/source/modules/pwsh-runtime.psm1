# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: Apache-2.0

Set-PSDebug -Strict
 # All Private modules merged into this file during build process to speed up module loading.
